/*****************************************************************************
* Include Files                                                              *
*****************************************************************************/

#include <stdio.h>
#include <stdlib.h>

// Driver header file
#include <pruss/prussdrv.h>
#include <pruss/pruss_intc_mapping.h>

// PRU-code
#include "PRU_demo_bin.h"

/*****************************************************************************
* Explicit External Declarations                                             *
*****************************************************************************/

/*****************************************************************************
* Local Macro Declarations                                                   *
*****************************************************************************/

#define PRU_NUM 	0

/*****************************************************************************
* Local Typedef Declarations                                                 *
*****************************************************************************/


/*****************************************************************************
* Local Function Declarations                                                *
*****************************************************************************/

/*****************************************************************************
* Local Variable Definitions                                                 *
*****************************************************************************/


/*****************************************************************************
* Intertupt Service Routines                                                 *
*****************************************************************************/


/*****************************************************************************
* Global Variable Definitions                                                *
*****************************************************************************/

/*****************************************************************************
* Global Function Definitions                                                *
*****************************************************************************/

int main (int argc, char *argv[])
{
    unsigned int ret;
    tpruss_intc_initdata pruss_intc_initdata = PRUSS_INTC_INITDATA;
    void *pruDataMem;
    int loops=5;
    
    printf("\nINFO: Starting %s example\n", 
           "PRU_demo");
    /* Initialize the PRU */
    prussdrv_init ();		
    
    /* Open PRU Interrupt */
    ret = prussdrv_open(PRU_EVTOUT_0);
    if (ret)
    {
        printf("prussdrv_open open failed\n");
        return (ret);
    }

    /* Get the interrupt initialized */
    prussdrv_pruintc_init(&pruss_intc_initdata);

    if(prussdrv_map_prumem (PRUSS0_PRU0_DATARAM, &pruDataMem)) {
        fprintf(stderr, "Failed to get mempointer to data ram for PRU%d\n",PRU_NUM);
        goto out;
    }
    
    if(prussdrv_pru_disable(PRU_NUM)) {
        fprintf(stderr, "Failed to disable PRU%d\n",PRU_NUM);
        goto out;
    }

    if(prussdrv_pru_reset(PRU_NUM)) {
        fprintf(stderr, "Failed to reset PRU%d\n",PRU_NUM);
        goto out;
    }

    if(0 > prussdrv_pru_write_memory(PRUSS0_PRU0_IRAM, 0, PRUcode, sizeof(PRUcode))) {
        fprintf(stderr, "Failed to load PRU%d code\n",PRU_NUM);
        goto out;
    }

    if(prussdrv_pru_enable(PRU_NUM)) {
        fprintf(stderr, "Failed to enable PRU%d\n",PRU_NUM);
        goto out;
    }

    while(loops) {
        prussdrv_pru_wait_event (PRU_EVTOUT_0);
        prussdrv_pru_clear_event (PRU0_ARM_INTERRUPT);
        loops--;
    }
    
    printf("INFO: Example executed succesfully.\r\n");

    /* Disable PRU and close memory mapping*/
    prussdrv_pru_disable (PRU_NUM);
 out:
    prussdrv_exit ();

    return(0);

}
